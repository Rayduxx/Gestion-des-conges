
<div class="layout-overlay layout-menu-toggle"></div>
<script src="./admin/assets/vendor/libs/jquery/jquery.js"></script>
<script src="./admin/assets/vendor/libs/popper/popper.js"></script>
<script src="./admin/assets/vendor/js/bootstrap.js"></script>
<script src="./admin/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="./admin/assets/vendor/js/menu.js"></script>
<script src="../assets/js/chatbot.js"></script>
<script src="./admin/assets/js/main.js"></script>
<script src="./admin/assets/js/Ala.js"></script>
<script src="../assets/js/blogs.js"></script>
<script src="./admin/assets/vendor/js/helpers.js"></script>
<script src="../assets/js/client.js"></script>
<script async defer src="https://buttons.github.io/buttons.js"></script>
</body>
</html>